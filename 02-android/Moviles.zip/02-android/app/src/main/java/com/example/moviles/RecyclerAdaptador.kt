package com.example.moviles
import androidx.recyclerview.widget.RecyclerView

class RecyclerAdaptador(
    private val listaUsuarios: List<UsuarioHttp>,
//    private val contexto
    private val recyclerView: androidx.recyclerview.widget.RecyclerView
) : androidx.recyclerview.widget.RecyclerView.Adapter<
        AdaptadorPersona.MyViewHolder
        > {


}